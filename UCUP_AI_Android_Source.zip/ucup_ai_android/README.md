# UCUP AI — proyek Android awal

Ini adalah **source project Android**, bukan APK siap instalasi. Buka folder ini menggunakan Android Studio.

## Fitur prototipe
- Antarmuka UCUP AI.
- Floating button yang dapat tampil di atas aplikasi lain (izin overlay diperlukan).
- Memilih foto/screenshot soal dari galeri atau penyimpanan.
- OCR menggunakan Google ML Kit Text Recognition.
- Mengirim teks soal ke Gemini 2.5 Flash dan menampilkan jawaban.

## Yang belum tersedia
- Tombol floating belum mengambil screenshot langsung dari layar aplikasi lain. Untuk versi berikutnya perlu alur MediaProjection Android (dialog izin tangkap layar dari sistem).
- Floating button prototipe membuka UCUP AI; belum menampilkan panel jawaban mini di atas aplikasi lain.
- Belum ada APK hasil build atau pengujian pada perangkat fisik.

## Cara membuka dan menjalankan
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini, lalu pilih **Open** dan pilih folder `ucup_ai_android`.
3. Tunggu Gradle Sync selesai.
4. Jalankan aplikasi pada HP Android 12+ dengan USB debugging atau emulator.
5. Buat Gemini API Key melalui Google AI Studio. Jangan bagikan API Key kepada orang lain.
6. Masukkan API Key di aplikasi lalu tekan **Simpan API Key**.
7. Beri izin tampil di atas aplikasi lain untuk mengaktifkan floating button.

## Catatan keamanan
Untuk prototipe, API Key disimpan lokal di SharedPreferences dan dipanggil langsung dari aplikasi. Ini cocok untuk uji coba pribadi, tetapi API Key dapat diekstrak dari aplikasi. Jangan gunakan pola ini untuk aplikasi publik/komersial; gunakan backend sendiri untuk menyimpan API Key.
