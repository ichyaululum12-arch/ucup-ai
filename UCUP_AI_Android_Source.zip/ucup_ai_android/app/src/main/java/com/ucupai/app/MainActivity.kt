package com.ucupai.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private lateinit var apiKey: EditText
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private val pickerCode = 2001
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9, 13, 24)
        buildUi()
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(android.graphics.Color.rgb(9, 13, 24))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
        }
        layout.addView(label("🤖  UCUP AI", 28f))
        layout.addView(label("Asisten pemindai soal dengan Gemini", 14f))
        apiKey = EditText(this).apply {
            hint = "Masukkan Gemini API Key"
            setHintTextColor(0xFF9CA3AF.toInt())
            setTextColor(-1)
            inputType = 0x00000081
            setSingleLine(true)
        }
        layout.addView(apiKey)
        val save = Button(this).apply {
            text = "Simpan API Key"
            setOnClickListener {
                val key = apiKey.text.toString().trim()
                if (key.isBlank()) toast("API Key belum diisi")
                else {
                    getSharedPreferences("ucup", MODE_PRIVATE).edit().putString("key", key).apply()
                    toast("API Key disimpan di perangkat")
                }
            }
        }
        layout.addView(save)
        val floating = Button(this).apply {
            text = "Aktifkan Floating Button"
            setOnClickListener {
                if (!android.provider.Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    toast("Floating button aktif")
                }
            }
        }
        layout.addView(floating)
        val scan = Button(this).apply {
            text = "Pilih Foto / Screenshot Soal"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "image/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }
                startActivityForResult(intent, pickerCode)
            }
        }
        layout.addView(scan)
        question = EditText(this).apply {
            hint = "Teks soal akan muncul di sini. Kamu juga bisa mengetik soal."
            setHintTextColor(0xFF9CA3AF.toInt())
            setTextColor(-1)
            minLines = 4
            gravity = Gravity.TOP
        }
        layout.addView(question)
        val ask = Button(this).apply {
            text = "Tanyakan ke Gemini"
            setOnClickListener { askGemini() }
        }
        layout.addView(ask)
        answer = label("Jawaban akan muncul di sini.", 16f)
        answer.setPadding(0, 22, 0, 0)
        layout.addView(answer)
        setContentView(ScrollView(this).apply { addView(layout) })
        apiKey.setText(getSharedPreferences("ucup", MODE_PRIVATE).getString("key", ""))
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerCode && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            recognizeImage(uri)
        }
    }

    private fun recognizeImage(uri: Uri) {
        answer.text = "Membaca gambar..."
        try {
            val image = InputImage.fromFilePath(this, uri)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(image)
                .addOnSuccessListener { result ->
                    question.setText(result.text)
                    answer.text = if (result.text.isBlank()) "Teks tidak terbaca. Coba gambar yang lebih jelas."
                                  else "Soal berhasil dibaca. Tekan Tanyakan ke Gemini."
                }
                .addOnFailureListener { answer.text = "Gagal membaca gambar: ${it.localizedMessage}" }
        } catch (e: Exception) {
            answer.text = "Tidak bisa membuka gambar: ${e.localizedMessage}"
        }
    }

    private fun askGemini() {
        val key = getSharedPreferences("ucup", MODE_PRIVATE).getString("key", "").orEmpty()
        val prompt = question.text.toString().trim()
        if (key.isBlank()) { toast("Masukkan dan simpan Gemini API Key terlebih dahulu"); return }
        if (prompt.isBlank()) { toast("Scan atau ketik soal terlebih dahulu"); return }
        answer.text = "Gemini sedang berpikir..."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) { callGemini(key, prompt) }
                answer.text = result
            } catch (e: Exception) {
                answer.text = "Terjadi kesalahan: ${e.message}\nPeriksa koneksi dan API Key."
            }
        }
    }

    private fun callGemini(key: String, prompt: String): String {
        val client = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
        val bodyJson = JSONObject().put("contents",
            org.json.JSONArray().put(JSONObject().put("parts",
                org.json.JSONArray().put(JSONObject().put("text",
                    "Jawab soal berikut dalam bahasa Indonesia. Berikan jawaban yang tepat dan penjelasan singkat.\\n\\n$prompt")))))
        val body = bodyJson.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$key")
            .post(body).build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}: $raw")
            val json = JSONObject(raw)
            return json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
